from django.shortcuts import render
from prediction.models import Deployment

def prediction_form(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        deployment_type = request.POST.get('deployment_type')
        application_field = request.POST.get('application_field')

        # Save the data to the database
        deployment = Deployment.objects.create(
            name=name,
            deployment_type=deployment_type,
            application_field=application_field
        )
        deployment.save()

        # Redirect to a success page or render a result template
        return render(request, 'success.html')

    return render(request, 'prediction_form.html')
